#!/usr/bin/env python3
"""Seal all repository recipe sources; excludes generated receipts/manifests."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDE = {
    "RECIPE_MANIFEST.json",
    "SOURCE_MANIFEST.json",
    "WHEEL_MANIFEST.json",
    "RUNTIME_CACHE_MANIFEST.json",
    "P1268_C1_C2_RESULT.json",
}
rows = []
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path.name in EXCLUDE or "__pycache__" in path.parts or "receipts" in path.parts:
        continue
    data = path.read_bytes()
    rows.append({"path": str(path.relative_to(ROOT)), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
payload = {
    "schema": "genesis-golden-recipe-manifest-v1",
    "truth_label": "PUBLIC_CANON_IQ3_WIRE; NOT P943 native TRUE-C",
    "p1268_result_sha256": "9b1d42fe3f4dcb28e7f8660b37f800fdbfdcd7f721fb4bc57ca31a0dda313860",
    "files": rows,
}
output = ROOT / "RECIPE_MANIFEST.json"
output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
print(json.dumps({"status": "PASS", "output": str(output), "files": len(rows), "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}, sort_keys=True))
