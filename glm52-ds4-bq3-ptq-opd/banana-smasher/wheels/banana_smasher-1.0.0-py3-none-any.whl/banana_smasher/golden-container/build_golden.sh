#!/usr/bin/env bash
# Redirect targets are task-owned; only the docker CLI requires sudo.
# shellcheck disable=SC2024
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TASK_ID="${TASK_ID:-t_8ad5e4bb}"
P1268="${P1268:-/home/dnola/missions/P1268_C2_CANON_VERBATIM_t_d21996d5_s8}"
VENV="${VENV:-/home/dnola/venvs/vllm-moet}"
CUBINS_W2="${CUBINS_W2:-/home/dnola/Dev/vLLM-Moet/kernels/cubins-sm120}"
CUBINS_W3="${CUBINS_W3:-/home/dnola/ds4w3/cubins_e43}"
TRITON_CACHE="${TRITON_CACHE:-/home/dnola/.triton/cache}"
FLASHINFER_CACHE="${FLASHINFER_CACHE:-/home/dnola/.cache/vllm/flashinfer_autotune_cache}"
FLASHINFER_JIT_CACHE="${FLASHINFER_JIT_CACHE:-/home/dnola/.cache/flashinfer}"
IMAGE="${IMAGE:-genesis-serve:golden}"
BASE_ALIAS="genesis-serve:p1135n-b66edfa3-closure"
BASE_ID="sha256:b66edfa3811486df5ad61f513861a08e99b7b7ffe18edf5c1f4ed494567631fe"
OUT="${OUT:-$HERE/receipts}"
REGISTRY="${REGISTRY:-}"
mkdir -p "$OUT"

command -v docker >/dev/null
command -v nvidia-smi >/dev/null
[[ "$(uname -m)" == "aarch64" ]] || { echo "golden image requires aarch64 Spark, got $(uname -m)" >&2; exit 2; }
compute_cap="$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader | head -n1 | tr -d ' ')"
[[ "$compute_cap" == 12.* ]] || { echo "golden image requires Blackwell compute capability 12.x, got $compute_cap" >&2; exit 2; }

PYOVERLAY="$P1268/runtime/pyoverlay"
M4="$P1268/kernel/vq_warp_public/vq_warp_gemv"

for required in \
  "$VENV/bin/python" \
  "$PYOVERLAY/vllm/models/deepseek_v4/quant_config.py" \
  "$M4/_C.so" "$M4/__init__.py" \
  "$P1268/receipts/P1268_C1_C2_RESULT.json" \
  "$CUBINS_W2" "$CUBINS_W3" "$TRITON_CACHE" "$FLASHINFER_CACHE" "$FLASHINFER_JIT_CACHE"; do
  [[ -e "$required" ]] || { echo "missing build input: $required" >&2; exit 3; }
done

actual_base="$(sudo -n docker image inspect genesis-serve:golden-bare --format '{{.Id}}')"
[[ "$actual_base" == "$BASE_ID" ]] || { echo "base drift: $actual_base != $BASE_ID" >&2; exit 4; }
sudo -n docker tag "$BASE_ID" "$BASE_ALIAS"

python3 "$HERE/make_wheel_manifest.py" \
  --python "$VENV/bin/python" \
  --venv "$VENV" \
  --pyoverlay "$PYOVERLAY" \
  --m4-root "$M4" \
  --output "$HERE/WHEEL_MANIFEST.json"
python3 "$HERE/make_runtime_cache_manifest.py" \
  --context cubins_w2 "$CUBINS_W2" \
  --context cubins_w3 "$CUBINS_W3" \
  --context triton_cache "$TRITON_CACHE" \
  --context flashinfer_cache "$FLASHINFER_CACHE" \
  --context flashinfer_jit_cache "$FLASHINFER_JIT_CACHE" \
  --output "$HERE/RUNTIME_CACHE_MANIFEST.json"
cp "$P1268/receipts/P1268_C1_C2_RESULT.json" "$HERE/P1268_C1_C2_RESULT.json"

python3 - "$HERE" "$P1268" "$VENV" "$CUBINS_W2" "$CUBINS_W3" "$TRITON_CACHE" "$FLASHINFER_CACHE" "$FLASHINFER_JIT_CACHE" <<'PY'
import hashlib, json, sys
from pathlib import Path
here, p1268, venv, c2, c3, triton, flash, flash_jit = map(Path, sys.argv[1:])
critical = {
    "base_image_id": "sha256:b66edfa3811486df5ad61f513861a08e99b7b7ffe18edf5c1f4ed494567631fe",
    "p1268_result": p1268 / "receipts/P1268_C1_C2_RESULT.json",
    "p1268_launcher": p1268 / "run/launch_p1268.sh",
    "runtime_overlay_receipt": p1268 / "runtime/pyoverlay/RUNTIME_OVERLAY_RECEIPT.json",
    "quant_config_preimage": p1268 / "runtime/pyoverlay/vllm/models/deepseek_v4/quant_config.py",
    "moe_w2_cubit": p1268 / "runtime/pyoverlay/vllm/model_executor/layers/quantization/utils/moe_w2_cubit.py",
    "moe_vq_triton": p1268 / "runtime/pyoverlay/vllm/model_executor/layers/quantization/utils/moe_vq_triton.py",
    "flashinfer_jit_core_preimage": venv / "lib/python3.12/site-packages/flashinfer/jit/core.py",
    "m4_binary": p1268 / "kernel/vq_warp_public/vq_warp_gemv/_C.so",
    "m4_wrapper": p1268 / "kernel/vq_warp_public/vq_warp_gemv/__init__.py",

    "python": venv / "bin/python",
}
def row(path):
    data=path.read_bytes(); return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
rows={name: row(path) for name,path in critical.items() if name != "base_image_id"}
# Context directory identity is represented by exact roots plus critical manifests;
# the image build itself seals every resulting layer by immutable image digest.
out={
 "schema":"genesis-golden-source-manifest-v2",
 "task_id":"t_8ad5e4bb",
 "truth_label":"PUBLIC_CANON_IQ3_WIRE; NOT P943 native TRUE-C",
 "base_image_id":critical["base_image_id"],
 "critical":rows,
 "contexts":["venv","pyoverlay","cubins_w2","cubins_w3","triton_cache","flashinfer_cache","flashinfer_jit_cache"],
 "no_model_or_wire_context":True,
}
(here/"SOURCE_MANIFEST.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
PY

# Refuse accidental model/wire payloads in the main recipe context.
python3 - "$HERE" <<'PY'
import sys
from pathlib import Path
root=Path(sys.argv[1])
allowed={"P1268_C1_C2_RESULT.json"}
for p in root.rglob("*"):
    if not p.is_file() or p.name in allowed:
        continue
    low=str(p.relative_to(root)).lower()
    if p.suffix in {".safetensors", ".bin"} or "wire_v4" in low or "true_c_planes" in low:
        raise SystemExit(f"forbidden model/wire payload in recipe context: {p}")
PY

avail="$(df --output=avail -B1 / | tr -d ' ' | sed -n '2p')"
(( avail >= 37580963840 )) || { echo "root below 35 GiB build floor: $avail" >&2; exit 5; }

export BUILDKIT_PROGRESS=plain
sudo -n ionice -c2 -n7 nice -n 10 docker buildx build \
  --load --pull=false --network=none --provenance=false --progress=plain \
  --build-context "venv=$VENV" \
  --build-context "pyoverlay=$PYOVERLAY" \
  --build-context "m4=$M4" \
  --build-context "m4_wrapper=$M4" \
  --build-context "cubins_w2=$CUBINS_W2" \
  --build-context "cubins_w3=$CUBINS_W3" \
  --build-context "triton_cache=$TRITON_CACHE" \
  --build-context "flashinfer_cache=$FLASHINFER_CACHE" \
  --build-context "flashinfer_jit_cache=$FLASHINFER_JIT_CACHE" \
  --tag "$IMAGE" --file "$HERE/Dockerfile" "$HERE" \
  2>&1 | tee "$OUT/IMAGE_BUILD.log"

sudo -n docker image inspect "$IMAGE" > "$OUT/IMAGE_INSPECT.json"
python3 - "$OUT/IMAGE_INSPECT.json" "$OUT/IMAGE_BUILD_RECEIPT.json" "$IMAGE" "$compute_cap" <<'PY'
import hashlib,json,sys,time
source,out,image,cap=sys.argv[1:]
inspect=json.load(open(source))[0]
config=inspect["Config"]
if config.get("Entrypoint") not in (None, []):
    raise SystemExit(f"unexpected entrypoint: {config.get('Entrypoint')}")
if config.get("Cmd",[])[:3] != ["vllm","serve","/model"]:
    raise SystemExit(f"non-stock command: {config.get('Cmd')}")
labels=config.get("Labels") or {}
if labels.get("io.genesis.no-model-bytes") != "true":
    raise SystemExit("no-model label missing")
if labels.get("io.genesis.external-pack.manifest.sha256") != "4a4c15a52eaa8f87e4eb2f436da1580cb5e9addb15713d41bd9a74276731578a":
    raise SystemExit("external pack digest label mismatch")
receipt={
 "schema":"genesis-golden-image-build-v1","status":"PASS","created_unix":time.time(),
 "image":image,"image_id":inspect["Id"],"repo_digests":inspect.get("RepoDigests") or [],
 "size":inspect["Size"],"architecture":inspect["Architecture"],"compute_capability":cap,
 "cmd":config["Cmd"],"entrypoint":config.get("Entrypoint"),"labels":labels,
 "inspect_sha256":hashlib.sha256(open(source,"rb").read()).hexdigest(),
 "truth_label":"PUBLIC_CANON_IQ3_WIRE; NOT P943 native TRUE-C",
}
open(out,"w").write(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
print(json.dumps(receipt,sort_keys=True))
PY

if [[ -n "$REGISTRY" ]]; then
  echo "REGISTRY inline push is disabled: use publish_local_registry.sh or push_local_registry_via_ssh.sh so publication is immutable-digest-bound" >&2
  exit 6
fi
printf 'PASS image=%s receipt=%s\n' "$IMAGE" "$OUT/IMAGE_BUILD_RECEIPT.json"
