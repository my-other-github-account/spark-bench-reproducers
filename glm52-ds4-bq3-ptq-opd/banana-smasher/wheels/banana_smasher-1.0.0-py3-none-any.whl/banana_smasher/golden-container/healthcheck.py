#!/usr/bin/env python3
"""Stock-semantics Docker health check: HTTP only, never benchmark traffic."""
from __future__ import annotations

import json
import os
import sys
import urllib.request
from pathlib import Path


def argv_value(argv: list[str], flag: str, default: str) -> str:
    for index, value in enumerate(argv):
        if value == flag and index + 1 < len(argv):
            return argv[index + 1]
        if value.startswith(flag + "="):
            return value.split("=", 1)[1]
    return default


base = os.environ.get("VLLM_HEALTHCHECK_URL")
if not base:
    try:
        argv = [part.decode() for part in Path("/proc/1/cmdline").read_bytes().split(b"\0") if part]
    except Exception:
        argv = []
    port = argv_value(argv, "--port", "8000")
    if not port.isdecimal() or not (1 <= int(port) <= 65535):
        print(f"NOT_READY: invalid --port in process argv: {port}", file=sys.stderr)
        raise SystemExit(1)
    base = f"http://127.0.0.1:{port}"
try:
    with urllib.request.urlopen(base + "/health", timeout=5) as response:
        if response.status != 200:
            raise RuntimeError(f"health HTTP {response.status}")
    with urllib.request.urlopen(base + "/v1/models", timeout=5) as response:
        if response.status != 200:
            raise RuntimeError(f"models HTTP {response.status}")
        models = json.load(response)
    if not (models.get("data") or []):
        raise RuntimeError("models list is empty")
except Exception as exc:
    print(f"NOT_READY: {exc}", file=sys.stderr)
    raise SystemExit(1)
print("READY")
