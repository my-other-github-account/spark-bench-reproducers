# banana-smasher

`banana-smasher` is the self-contained, fail-closed `bs-pack v1` toolchain used by the private vLLM fork. The format contract, exporter, validator, loader, safetensors repacker, validation ceremony, and container recipe live in this package. See `BANANA_PACK_SPEC.md` for the frozen schema and detection-key tables.

## Install and test

```bash
uv venv --python 3.13
uv pip install --python .venv/bin/python -e '.[test]'
.venv/bin/python -m pytest
```

No command requires `PYTHONPATH`, sitecustomize, a mission-directory convention, or launcher-only environment variables.

## The five lifecycle verbs

### 1. Export

```bash
smash export \
  --source-root /path/to/quantizer-output \
  --output /path/to/bs-pack \
  --model-id MODEL \
  --instance-id bs-pack-0001-genesis \
  --link-mode hardlink \
  --safetensors
```

The exporter writes per-layer `.npy`/raw planes, generated `meta.json`, `config.json`, and the complete SHA-256/byte-count manifest. `--drop-planes` is allowed only with `--safetensors` and only after payload-exact verification.

### 2. Verify

```bash
smash verify /path/to/bs-pack
```

This validates the schema, complete file set, byte counts, SHA-256 values, config detection keys, per-layer metadata, tier maps, required family tensors, and safetensors payload identity. Reproducibility automation may use the compatibility spelling `smash validate-pack /path/to/bs-pack`; it is the same fail-closed validator and does not add a sixth lifecycle concept.

### 3. Serve-check

```bash
smash serve-check /path/to/bs-pack \
  --kernel-cache /path/to/kernel-cache \
  --architecture sm_120
```

This first runs the full pack verifier, then requires an exact kernel-cache ABI/layout/family/architecture match.

### 4. Validate

```bash
smash validate /path/to/artifact \
  --bank holdout512_v1 \
  --check-exposure \
  --receipt VALIDATION_RECEIPT.json
```

The command locates and verifies the bank plus its teacher-logit companion, refuses training-manifest exposure, runs the student-logit pass, reports global and per-class KLD with named baselines, and seals provenance. If banked teacher logits are absent, provide them once with `--bank-teacher-logits`; the command never silently re-walks a teacher.

### 5. Bootstrap

```bash
smash bootstrap \
  --context /path/to/sealed/build-context \
  --image genesis-serve:candidate \
  --receipt BOOTSTRAP_RECEIPT.json
```

The packaged backing is the manifest-sealed P1268 `golden-container/` recipe authored by the container-capture lane. It preserves stock vLLM command semantics and the truth label `PUBLIC_CANON_IQ3_WIRE; NOT P943 native TRUE-C`. Build and publication remain separate gates; bootstrap does not publish or bless a tag.

## Serve normally

A generic bs-pack advertises `quantization_config.quant_method=bs-mixed-tier`; the fork auto-detects it exactly like other checkpoint quantization methods:

```bash
vllm serve /path/to/bs-pack \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.8 \
  --port 8000
```

Every normal vLLM flag retains its stock meaning. The captured P1268 compatibility profile instead preserves the checkpoint's registered FP8 method and selects its vendored backend with `moe_quant_algo=IQ3_WIRE` plus `moe_pack_root=wire_v4-step32`; the spec table documents this distinction so the two layouts cannot be silently confused.

Every `smash` command emits a machine-readable JSON receipt. Validation failures return exit code 2.

## Shared loader

```python
from banana_smasher.loader import PackLoader

loader = PackLoader(pack_root, verify=True)
with loader.open_layer(0, framework="pt") as layer:
    tier_map = layer.get("layers.0.experts.tier_map")
```

Exporter, validator, safetensors repacker, preflight, and the private vLLM method consume the same contract/loader implementation; there is no second format parser.
